import React, { useEffect, useState } from "react";
import axios from "axios";
import EducationForm from "./EducationForm";
const EducationDetail = () => {
  const [names, setNames] = useState([]);
  useEffect(() => {
    axios
      .get("http://localhost:3001/education-detail/college-names")
      .then((response) => {
        setNames((prevState) => response.data.names);
        console.log(response.data);
      });
  }, []);
  const [count, setCount] = useState([1]);
  const addCount = () => {
    if (count.length < 3) {
      setCount((prevState) => [
        ...prevState,
        Number(count[count.length - 1]) + 1,
      ]);
      setEducationDetail((prevState) => [
        ...prevState,
        {
          "college/uni": "",
          passing_year: "",
          marks: "",
          graduation: false,
          post_graduation: false,
        },
      ]);
      console.log("edSatteOnFunction : ", educationDetails);
    }
    console.log(count);
  };

  const removeEducation = (index) => {
    console.log(count.length);
    if (count.length > 1) {
      educationDetails.splice(index, 1);
      let newCount = count.filter((data) => {
        return data !== count[index];
      });
      console.log(newCount);
      setCount((prevState) => newCount);
    }
  };
  const [educationDetails, setEducationDetail] = useState([
    {
      "college/uni": "",
      passing_year: "",
      marks: "",
      graduation: false,
      post_graduation: false,
    },
  ]);

  const addEducation = (e) => {
    e.preventDefault();
    console.log(educationDetails);
  };
  console.log(educationDetails);
  return (
    <>
      <div className="education-detail bg-lt-purple ">
        <h1 className="white">Education Detail</h1>
        <form className="education-form bg-white " onSubmit={addEducation}>
          <div className="education-form-div">
            {count.map((data, index) => (
              <EducationForm
                key={index + Math.random()}
                educationDetails={educationDetails}
                setEducationDetail={setEducationDetail}
                addEducation={addEducation}
                count={count}
                names={names}
                addCount={addCount}
                removeEducation={removeEducation}
                index={index}
              />
            ))}
            <div
              className="margin-bottom-5"
              style={{
                width: "100%",
              }}
            >
              <button
                className="input-field input-button bg-lt-purple"
                type="button"
                onClick={() => addCount()}
              >
                ADD EDUCATION
              </button>

              <button
                className="input-field input-button bg-lt-purple"
                type="submit"
              >
                SUBMIT DETAILS
              </button>
            </div>
          </div>
        </form>
      </div>
    </>
  );
};

export default EducationDetail;
